#include "FloatNumber.h"

using namespace std;

FloatNumber::FloatNumber() : Number(0) {
	this->floating_part = 0;
}

FloatNumber::FloatNumber(int a, int b) : Number(a) {
	this->floating_part = b;
}

FloatNumber::FloatNumber(const FloatNumber& fn) : Number(fn) {
	this->floating_part = fn.getFloating();
}

FloatNumber& FloatNumber::operator=(const FloatNumber& fn) {
	if (this != &fn) {
		Number::operator=(fn);
		this->floating_part = fn.getFloating();
	}

	return *this;
}

FloatNumber::~FloatNumber() {}

void FloatNumber::setFloating(const int f) {
	this->floating_part = f;
}

const int FloatNumber::getFloating() const {
	return this->floating_part;
}

bool FloatNumber::operator==(const FloatNumber& fn) {
	if (getNum() == fn.getNum() && getFloating() == fn.getFloating()) {
		return true;
	}

	return false;
}

bool FloatNumber::operator!=(const FloatNumber& fn) {
	if (getNum() != fn.getNum() || getFloating() != fn.getFloating()) {
		return true;
	}

	return false;
}

bool FloatNumber::operator<(const FloatNumber& fn) {
	if (getNum() < fn.getNum() && getFloating() == fn.getFloating()) {
		return true;
	}
	else if (getNum() == fn.getNum() && getFloating() < fn.getFloating()) {
		return true;
	}
	else if (getNum() < fn.getNum() && getFloating() < fn.getFloating()) {
		return true;
	}

	return false;
}

bool FloatNumber::operator>(const FloatNumber& fn) {
	if (getNum() > fn.getNum() && getFloating() == fn.getFloating()) {
		return true;
	}
	else if (getNum() == fn.getNum() && getFloating() > fn.getFloating()) {
		return true;
	}
	else if (getNum() > fn.getNum() && getFloating() > fn.getFloating()) {
		return true;
	}

	return false;
}

void FloatNumber::print_float() const {
	Number::print();
	cout << "." << getFloating() << endl;
}