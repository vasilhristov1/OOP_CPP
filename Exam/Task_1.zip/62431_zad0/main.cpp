#include "Number.h"
#include "FloatNumber.h"

using namespace std;

int main() {
	FloatNumber a(1, 23);
	FloatNumber b(2, 54);

	a.print_float();
	b.print_float();

	cout << "a == b: " << (a == b) << endl;
	cout << "a != b: " << (a != b) << endl;
	cout << "a > b: " << (a > b) << endl;
	cout << "a < b: " << (a < b) << endl;

	FloatNumber c;
	c = a;
	c.print_float();

	return 0;
}