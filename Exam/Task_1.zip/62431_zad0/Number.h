#pragma once
#include <iostream>

using namespace std;

class Number {
public:
	Number();
	Number(int);
	Number(const Number&);
	Number& operator=(const Number&);
	~Number();

	void setNum(const int);

	const int getNum() const;

	bool operator==(const Number&);
	bool operator!=(const Number&);
	bool operator>(const Number&);
	bool operator<(const Number&);

	void print() const;
private:
	int num;
};