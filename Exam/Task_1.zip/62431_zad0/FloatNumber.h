#pragma once
#include <iostream>
#include "Number.h"

using namespace std;

class FloatNumber : public Number {
public:
	FloatNumber();
	FloatNumber(int, int);
	FloatNumber(const FloatNumber&);
	FloatNumber& operator=(const FloatNumber&);
	~FloatNumber();

	void setFloating(const int);

	const int getFloating() const;

	bool operator==(const FloatNumber&);
	bool operator!=(const FloatNumber&);
	bool operator>(const FloatNumber&);
	bool operator<(const FloatNumber&);

	void print_float() const;
private:
	int floating_part;
};