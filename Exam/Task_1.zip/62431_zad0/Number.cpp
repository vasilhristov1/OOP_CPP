#include "Number.h"

using namespace std;

Number::Number() {
	this->num = 0;
}

Number::Number(int n) {
	this->num = n;
}

Number::Number(const Number& number) {
	this->num = number.getNum();
}

Number& Number::operator=(const Number& number) {
	if (this != &number) {
		this->num = number.getNum();
	}

	return *this;
}

Number::~Number() {}

void Number::setNum(const int n) {
	this->num = n;
}

const int Number::getNum() const {
	return this->num;
}

bool Number::operator==(const Number& number) {
	if (this->num == number.getNum()) {
		return true;
	}

	return false;
}

bool Number::operator!=(const Number& number) {
	if (this->num != number.getNum()) {
		return true;
	}

	return false;
}

bool Number::operator>(const Number& number) {
	if (this->num > number.getNum()) {
		return true;
	}

	return false;
}

bool Number::operator<(const Number& number) {
	if (this->num < number.getNum()) {
		return true;
	}

	return false;
}

void Number::print() const {
	cout << getNum();
}