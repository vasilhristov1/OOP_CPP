#pragma once
#include <iostream>

using namespace std;

template<typename T>
class IdObject {
public:
	IdObject(T, int);

	T getObj() const;
	int getID() const;

	bool operator==(const IdObject&);
	bool operator!=(const IdObject&);
	bool operator>(const IdObject&);
	bool operator<(const IdObject&);
private:
	T obj;
	int id;
};

template<typename T>
inline IdObject<T>::IdObject(T o, int i) {
	this->obj = o;
	this->id = i;
}

template<typename T>
inline T IdObject<T>::getObj() const {
	return this->obj;
}

template<typename T>
inline int IdObject<T>::getID() const {
	return this->id;
}

template<typename T>
inline bool IdObject<T>::operator==(const IdObject& io) {
	if (obj == io.getObj() && id == io.getID()) {
		return true;
	}

	return false;
}

template<typename T>
inline bool IdObject<T>::operator!=(const IdObject& io) {
	if (obj != io.getObj() && id != io.getID()) {
		return true;
	}

	return false;
}

template<typename T>
inline bool IdObject<T>::operator>(const IdObject& io) {
	if (id > io.getID()) {
		return true;
	}

	return false;
}

template<typename T>
inline bool IdObject<T>::operator<(const IdObject& io) {
	if (id < io.getID()) {
		return true;
	}

	return false;
}

template<typename T>
class IdObjectContainer {
public:
	IdObjectContainer();
	IdObjectContainer(const IdObjectContainer&);
	IdObjectContainer<T>& operator=(const IdObjectContainer&);
	~IdObjectContainer();

	int getSize() const;
	int getCap() const;

	void addObject(const IdObject<T>&);

	IdObject<T> operator[](int index) const;
	bool operator==(const IdObjectContainer&);
	int getDifferent() const;
private:
	IdObject<T>* objects = nullptr;

	int size;
	int cap;

	void copy(const IdObjectContainer&);

	void resize();

	void incrementSize();
	bool isFull() const;
	bool isEmpty() const;

};

template<typename T>
inline void IdObjectContainer<T>::copy(const IdObjectContainer& ioc) {
	setSize(ioc.getSize());
	setCap(ioc.getCap());

	objects = new IdObjects<T>[ioc.getCap()];

	for (int i = 0; i < ioc.getSize(); i++) {
		objects[i] = ioc[i];
	}
}

template<typename T>
inline void IdObjectContainer<T>::resize() {
	setCap(2 * getCap());

	IdObject<T>* newObj = new IdObject<T>[getCap()];

	for (int i = 0; i < getSize(); i++) {
		newObj[i] = objects[i];
	}

	delete[] this->objects;
	this->objects = newObj;
}

template<typename T>
inline void IdObjectContainer<T>::incrementSize() {
	this->size++;
}

template<typename T>
inline bool IdObjectContainer<T>::isFull() const {
	return (getSize() == getCap());
}

template<typename T>
inline bool IdObjectContainer<T>::isEmpty() const {
	return (getSize() == 0);
}

template<typename T>
inline IdObjectContainer<T>::IdObjectContainer() {
	size = 0;
	cap = 2;
	objects = new IdObjects<T>[cap];
}

template<typename T>
inline IdObjectContainer<T>::IdObjectContainer(const IdObjectContainer& ioc) {
	copy(ioc);
}

template<typename T>
inline IdObjectContainer<T>& IdObjectContainer<T>::operator=(const IdObjectContainer& ioc) {
	if (this != &ioc) {
		delete[] this->objects;
		copy(ioc);
	}

	return *this;
}

template<typename T>
inline IdObjectContainer<T>::~IdObjectContainer() {
	delete[] this->objects;
}

template<typename T>
inline void IdObjectContainer<T>::addObject(const IdObject<T>& ob) {
	if (isFull()) resize();
	incrementSize();
	objects[getSize() - 1] = ob;
}

template<typename T>
inline int IdObjectContainer<T>::getSize() const {
	return this->size;
}

template<typename T>
inline int IdObjectContainer<T>::getCap() const {
	return this->cap;
}

template<typename T>
inline IdObject<T> IdObjectContainer<T>::operator[](int index) const {
	if (index > getSize() || index < 0) {
		throw "out_of_range";
	}
	
	return objects[index];
}

template<typename T>
inline bool IdObjectContainer<T>::operator==(const IdObjectContainer& ioc) {
	if (getSize() == ioc.getSize()) {
		for (int i = 0; i < ioc.getSize(); i++) {
			if (objects[i] != ioc.objects[i]) {
				return false;
			}
		}
		return true;
	}

	return false;
}

template<typename T>
inline int IdObjectContainer<T>::getDifferent() const {
	int dif = 0;
	for (int i = 0; i < getSize(); i++) {
		for (int j = 0; j < getSize(); j++) {
			if (objects[i] != objects[j]) {
				dif++;
			}
		}
	}

	return dif;
}