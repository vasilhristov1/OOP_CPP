#pragma once
#include <iostream>
#include <string>
#include <vector>

using namespace std;

class ShopItem {
public:
	ShopItem();
	ShopItem(string, double);

	void setName(const string);
	void setPrice(const double);

	const string getName() const;
	const double getPrice() const;

	virtual ShopItem* clone() const = 0;
	virtual void print() const;
protected:
	string name;
	double price;
};