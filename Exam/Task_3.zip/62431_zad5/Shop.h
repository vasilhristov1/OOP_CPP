#pragma once
#include <iostream>
#include <vector>
#include <string>
#include "ShopItem.h"
#include "Food.h"
#include "Drink.h"

using namespace std;

class Shop {
public:
	Shop();
	Shop(const Shop& s);
	Shop& operator=(const Shop& s);
	~Shop();

	void addDrink(const Drink*);
	void addFood(const Food*);

	ShopItem* getObject(int index) const;

	void printAllProducts() const;
private:
	vector<ShopItem*> items;
};