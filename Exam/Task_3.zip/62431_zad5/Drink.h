#pragma once
#include "ShopItem.h"

using namespace std;

class Drink : public ShopItem {
public:
	Drink();
	Drink(string, double, double);

	void setQuantity(const double);
	const double getQuantity() const;

	virtual ShopItem* clone() const;
	virtual void print() const;
private:
	double quantity;
};