#include "ShopItem.h"

using namespace std;

ShopItem::ShopItem() : name(""), price(0.0) {}
ShopItem::ShopItem(string n, double p) : name(n), price(p) {}

void ShopItem::setName(const string n) {
	this->name = n;
}

void ShopItem::setPrice(const double p) {
	this->price = p;
}

const string ShopItem::getName() const {
	return this->name;
}

const double ShopItem::getPrice() const {
	return this->price;
}

void ShopItem::print() const {
	cout << "Name: " << getName() << endl;
	cout << "Price: " << getPrice() << endl;
}