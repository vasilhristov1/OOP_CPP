#include "ShopItem.h"
#include "Drink.h"

using namespace std;

Drink::Drink() : ShopItem("", 0.0) {
	this->quantity = 0.0;
}

Drink::Drink(string n, double p, double q) : ShopItem(n, p) {
	this->quantity = q;
}

void Drink::setQuantity(const double q) {
	this->quantity = q;
}

const double Drink::getQuantity() const {
	return this->quantity;
}

ShopItem* Drink::clone() const {
	return new Drink(*this);
}

void Drink::print() const {
	ShopItem::print();
	cout << "Quantity: " << getQuantity() << endl;
}