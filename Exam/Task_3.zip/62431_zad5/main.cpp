#include <iostream>
#include "ShopItem.h"
#include "Food.h"
#include "Drink.h"
#include "Shop.h"

using namespace std;

int main() {
	Shop s;

	Food f1("f1", 12.50, 123.2);
	Food f2("f2", 11.50, 13.2);
	Food f3("f3", 14.50, 23.2);
	Food f4("f4", 17.50, 12.2);
	Drink d1("d1", 1.6, 2.0);
	Drink d2("d2", 2.6, 5.0);
	Drink d3("d3", 3.6, 4.0);
	Drink d4("d4", 4.6, 1.0);

	ShopItem* ptr1 = &f1;
	ShopItem* ptr2 = &f2;
	ShopItem* ptr3 = &f3;
	ShopItem* ptr4 = &f4;
	ShopItem* ptr5 = &d1;
	ShopItem* ptr6 = &d2;
	ShopItem* ptr7 = &d3;
	ShopItem* ptr8 = &d4;



	return 0;
}