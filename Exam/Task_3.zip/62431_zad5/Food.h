#pragma once
#include "ShopItem.h"

using namespace std;

class Food : public ShopItem {
public:
	Food();
	Food(string, double, double);

	void setKcals(const double);
	const double getKcals() const;

	virtual ShopItem* clone() const;
	virtual void print() const;
private:
	double Kcals;
};