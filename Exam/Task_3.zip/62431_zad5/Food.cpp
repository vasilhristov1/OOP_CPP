#include "ShopItem.h"
#include "Food.h"

using namespace std;

Food::Food() : ShopItem("", 0.0) {
	this->Kcals = 0.0;
}

Food::Food(string n, double p, double k) : ShopItem(n, p) {
	this->Kcals = k;
}

void Food::setKcals(const double k) {
	this->Kcals = k;
}

const double Food::getKcals() const {
	return this->Kcals;
}

ShopItem* Food::clone() const {
	return new Food(*this);
}

void Food::print() const {
	ShopItem::print();
	cout << "Kcals: " << getKcals() << endl;
}