#include "Shop.h"
#include <vector>

using namespace std;

Shop::Shop() {}

Shop::Shop(const Shop& s) {
	for (int i = 0; i < items.size(); i++) {
		items[i] = s.items[i]->clone();
	}
}

Shop& Shop::operator=(const Shop& s) {
	if (this != &s) {
		for (int i = 0; i < items.size(); i++) {
			delete items[i];
		}
		items.clear();

		for (int i = 0; i < s.items.size(); i++) {
			items.push_back(s.items[i]->clone());
		}
	}
	return *this;
}

Shop::~Shop() {
	for (int i = 0; i < items.size(); i++) {
		delete items[i];
	}
	items.clear();
}

void Shop::addDrink(const Drink* d) {
	items.push_back(d->clone());
}


void Shop::addFood(const Food* f) {
	items.push_back(f->clone());
}

ShopItem* Shop::getObject(int index) const {
	if (index < items.size() && index >= 0) {
		return items[index];
	}
}

void Shop::printAllProducts() const {
	for (int i = 0; i < items.size(); i++) {
		items[i]->print();
	}
}